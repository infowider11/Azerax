<?php include_once 'include/header2.php';

?>
<style type="text/css">
	#showSearchDiv.show_div {
	display: block;
}
.select2-search.select2-search--inline {
	width: 100% !important;
}
.select2-search__field {
	width: 100% !important;
}

.autocomplete {
	width: 100%;
}
.autocomplete-items {
	position: absolute;
	z-index: 99;
	background: #fff;
	width: 100%;
	max-height: 150px;
	overflow-y: auto;
	overflow-x: hidden;
}
.autocomplete-items > div {
	width: 100%;
	color: #666;
	padding: 6px 15px;
	cursor: pointer;
}
.autocomplete-items > div strong{
	color: #333;
}
.autocomplete-items > div:hover {
	background: #14213d;
	color: #ccc;
}
.autocomplete-items > div:hover strong {
	color: #fff;
}
#processSugguestion {
	display: none;
}

.autocomplete-items .autocomplete-active{
  background-color: #14213d; 
  color: #ccc; 
}
.autocomplete-items .autocomplete-active strong{
  color: #fff; 
}
</style>


</style>

      <section class="home_banner_area">
				<div class="banner_inner d-flex align-items-center">
								<div class="container">
									<div class="search-form-container">
								<form method="get" class="search-form" action="<?php echo base_url();?>search-listing">
								    
								<h1 id="search-form-title">search for devices, components, services</h1>
								


									<div class="search-container">
										<div class="search-inner-container" style="z-index: 1;">

											<div class="search-inner-container" style="z-index: 1;">


												<div class=" rui-search-container search-input-container">
													<i class="lnr lnr-magnifier"></i>
  <div class="autocomplete" >

													<input data-toggle="#hidden1" class="rui-input rui-location-box rui-auto-complete-input"   autocomplete="off" placeholder="Search for devices" id="device_name" name="keyword" >												
</div>
                                                     
						
													<div class="clear-text-container">
														<a class="rui-icon rui-icon-cross" title="Clear text"> 
													</a>
												</div>
													<button type="submit" class="btn main_btn signup_btn"><!-- rui-search-button -->
														<span class="rui-visually">Search</span>
													</button>
													<div class="focus-border" style="display: none;"></div>
												</div>
												
												 <input type="hidden" name="productid" id="productid" />
												 <div class="hidden" id="hidden1" style="display: none;" data-hidden="true">
						                                <ul style="color: white;" id="processSugguestion" ></ul>
						                              </div>  
											</div>

						<center>
							<input type="button"  class="btn main_btn signup_btn spance_nav" value="Advance Search" id="btnShowHide" style="margin-top:21px;"/>
						</center>

					<nav class="search-channel-container search_new_des">
						
                 <aside class="search_new_des2" id="divShowHide" style="display: none; ">
											 <div class="">
											 	<ul class="list">
											 		<li class="">
											 			<div class="btn_usch" >
											 				<div class="" >
											 	<!--<input type="checkbox" name="by_input" value=1>-->
											 				By Input
											 			</div>
											 			
											 			</div>
	<div class="loop_inp">
		<div class="row">
            <div class="col-sm-4">
				<div class="form-group">
					<!-- <input type="text" data-role="tagsinput" name="input_name" placeholder="Input Type" class="form-control"> -->

	<select id="e2_2" name="input_name[]" class="inputF  form-control " multiple="multiple" >
               <?php     
                $data = array();
                $Input = $this->common_model->GetAllData('input_output','','input_conn','asc','','','','input_conn'); 
                foreach($Input as $InputSugg){
                
                
               $key= explode(',',$InputSugg['input_conn']);
               
               foreach($key as $k){
                   if($k){
                  // echo '<option>'.$k.'</option>';
                   }
                 $data[] =$k ;  
               }  
                }
                $data=array_unique($data);
               foreach($data as $k){
                   if($k){
                   echo '<option>'.$k.'</option>';
                   }
                  
               }
               $data=array();
               ?>
                 </select>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="form-group">
					<!-- <input type="text" data-role="tagsinput" name="input_stand" placeholder="Input Standard" class="form-control"> -->

					<select name="input_stand[]" class="typeahead instand tm-input form-control " style="width:300px" multiple="multiple" >

             <?php     

                $Input = $this->common_model->GetAllData('input_output','','input_process_stand','asc','','','','input_process_stand'); 
                foreach($Input as $InputSugg){
                
                
               $key= explode(',',$InputSugg['input_process_stand']);
               
                foreach($key as $k){
                   if($k){
                  // echo '<option>'.$k.'</option>';
                   }
                 $data[] =$k ;  
               }  
                }
                $data=array_unique($data);
               foreach($data as $k){
                   if($k){
                   echo '<option>'.$k.'</option>';
                   }
                  
               }
               $data=array();
               
               ?>
              
             
             </select>

				</div>
			</div>
			<div class="col-sm-4">
				<div class="form-group">
					<!-- <input type="text" data-role="tagsinput" name="input_conn" placeholder="Input Connection Type" class="form-control"> -->
					<select name="input_conn[]" class="typeahead inprocessConnection tm-input form-control " style="width:300px" multiple="multiple" class="populate placeholder">

             <?php     

                $Input = $this->common_model->GetAllData('input_output','','process_connection','asc','','','','process_connection');
                foreach($Input as $InputSugg){
                
                
               $key= explode(',',$InputSugg['process_connection']);
               
                foreach($key as $k){
                   if($k){
                  // echo '<option>'.$k.'</option>';
                   }
                 $data[] =$k ;  
               }  
                }
                $data=array_unique($data);
               foreach($data as $k){
                   if($k){
                   echo '<option>'.$k.'</option>';
                   }
                  
               }
               $data=array();
               
               ?>
              
             
             </select>
             
				</div>
			</div>
		</div>
	
	</div>
	
	</li> 


											 		


											 			<li class="">
											 				<div class="btn_usch">
											 				<div class="">
											 <!--<input type="checkbox" name="by_output" value=1 > -->
											 					By output
											 				</div>
											 			</div>
<div class="loop_inp">
		<div class="row">
			<div class="col-sm-4">
				<div class="form-group">
					<!-- <input type="text" name="out_conn" data-role="tagsinput" placeholder="Output Type" class="form-control"> -->
					<select name="out_conn[]" class="typeahead outputF tm-input form-control " style="width:300px" multiple="multiple" class="populate placeholder">

             <?php     

                $Input = $this->common_model->GetAllData('input_output','','out_conn','asc','','','','out_conn');
                foreach($Input as $InputSugg){
                
                
               $key= explode(',',$InputSugg['out_conn']);
               
                foreach($key as $k){
                   if($k){
                  // echo '<option>'.$k.'</option>';
                   }
                 $data[] =$k ;  
               }  
                }
                $data=array_unique($data);
               foreach($data as $k){
                   if($k){
                   echo '<option>'.$k.'</option>';
                   }
                  
               }
               $data=array();
               
               ?>
              
             
             </select>
              
				</div>
			</div>
			<div class="col-sm-4">
				<div class="form-group">
					<!-- <input type="text" name="out_process_stand" data-role="tagsinput" placeholder="Output Standard" class="form-control"> -->
					<select name="out_process_stand[]" class="typeahead otstand tm-input form-control " style="width:300px" multiple="multiple" class="populate placeholder">

             <?php     

                $Input = $this->common_model->GetAllData('input_output','','out_process_stand','asc','','','','out_process_stand'); 
                foreach($Input as $InputSugg){
                
                
               $key= explode(',',$InputSugg['out_process_stand']);
               
               foreach($key as $k){
                   if($k){
                  // echo '<option>'.$k.'</option>';
                   }
                   $data[] =$k ;  
                  }  
                }
                $data=array_unique($data);
               foreach($data as $k){
                   if($k){
                   echo '<option>'.$k.'</option>';
                   }
                  
               }
               $data=array();
               
               ?>
              
             
             </select>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="form-group">
					<!-- <input type="text" name="out_process_connection" data-role="tagsinput" placeholder="Output Connection Type" class="form-control"> -->
					<select name="out_process_connection[]" class="typeahead otprocessConnection tm-input form-control " style="width:300px" multiple="multiple" class="populate placeholder">

             <?php     

                $Input = $this->common_model->GetAllData('input_output','','out_process_connection','asc','','','','out_process_connection'); 
                foreach($Input as $InputSugg){
                
                
               $key= explode(',',$InputSugg['out_process_connection']);
               
                foreach($key as $k){
                   if($k){
                  // echo '<option>'.$k.'</option>';
                   }
                 $data[] =$k ;  
               }  
                }
                $data=array_unique($data);
               foreach($data as $k){
                   if($k){
                   echo '<option>'.$k.'</option>';
                   }
                  
               }
               $data=array();
               
               ?>
              
             
             </select>
				</div>
			</div>
		</div>
	
	</div>											 			
					
		</li>

	<li class="">
	    
											 			<div class="btn_usch">
											 			<div class="">
											 				<!--<input type="checkbox" name="by_process" value=1 >-->
											 				By proces
											 			</div>
											 			
											 		</div>
<div class="loop_inp">
		<div class="row justify-content-end">
			<div class="col-sm-4">
				<div class="form-group">
					<!-- <input type="text" data-role="tagsinput" name="process" placeholder="Process Type" class="form-control"> -->

					 <select name="process[]" class="typeahead processsuggestion tm-input form-control " style="width:300px" multiple="multiple" class="populate placeholder">

             <?php     

                $Input = $this->common_model->GetAllData('input_output','','process','asc','','','','process'); 
                foreach($Input as $InputSugg){
                
                
               $key= explode(',',$InputSugg['process']);
               
               foreach($key as $k){
                   if($k){
                  // echo '<option>'.$k.'</option>';
                   }
                 $data[] =$k ;  
               }  
                }
                $data=array_unique($data);
               foreach($data as $k){
                   if($k){
                   echo '<option>'.$k.'</option>';
                   }
                  
               }
               $data=array();
               ?>
              
             
             </select>

				</div>
			</div>
			<div class="col-sm-4">
				<div class="form-group">
					<!-- <input type="text" data-role="tagsinput" name="process_stand" placeholder="Process Standard" class="form-control"> -->
					<select name="process_stand[]" class="typeahead processsuggestionStand tm-input form-control " style="width:300px" multiple="multiple" class="populate placeholder">

             <?php     

                $Input = $this->common_model->GetAllData('input_output','','process_stand','asc','','','','process_stand');  
                foreach($Input as $InputSugg){
                
                
               $key= explode(',',$InputSugg['process_stand']);
               
                foreach($key as $k){
                   if($k){
                  // echo '<option>'.$k.'</option>';
                   }
                 $data[] =$k ;  
               }  
                }
                $data=array_unique($data);
               foreach($data as $k){
                   if($k){
                   echo '<option>'.$k.'</option>';
                   }
                  
               }
               $data=array();
               
               ?>
              
             
             </select>
              
				</div>
			</div>
			<div class="col-sm-4">
				<div class="form-group btn_serch_bo1">
					<button class="btn main_btn signup_btn">Search</button>
				</div>
			</div>
			
		</div>
		<!-- <div class="toop_t">
			<div class="primary-checkbox" data-toggle="tooltip" data-placement="top" title="Add Another">
			<input type="checkbox" id="check2"> 
			<label for="check2"></label>
		</div>
		</div> -->
	</div>
											 		</li>
											 		

											 		</ul>
											 	</div>
											 </aside>
											</nav>

										</div>
										</div>


										<div class="rui-clearfix"></div>
									
								</form>

									</div>
							</div>
									<!-- <div class="banner_content row">
										<div class="col-lg-5">
											<h3>Georgia Helmet <br />Collections!</h3>
											<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>
											<a class="white_bg_btn" href="#">View Collection</a>
										</div>
										<div class="col-lg-7">
											<div class="halemet_img">
												<img src="img/banner/helmat.png" alt="">
											</div>
										</div>
									</div> -->
								</div>


						</section>



	<?php include_once 'include/footer2.php' ; ?>
   <script type="text/javascript">
		$(document).ready(function(){
			//alert('yes');
		   $("#btnShowHide").click(function(){
		    	$("#divShowHide").toggle();
				});
			});
	</script>
<script type="text/javascript" class="js-code-example-tokenizer"> 

//input scrip select

$(".inputF").select2({     placeholder: "Input Type",
tags: true, tokenSeparators: [';'],
                            separator: ";",     multiple: true,
});

$(".instand").select2({ tags: true,placeholder: "Input Standard", tokenSeparators: [','] });

$(".inprocessConnection").select2({ tags: true,placeholder: "Input Connection Type", tokenSeparators: [',', ''] });


</script>
<script type="text/javascript" class="js-code-example-tokenizer"> 

//output scrip select

$(".outputF").select2({ tags: true,placeholder: "Output Type", tokenSeparators: [',', ' '] });

$(".otstand").select2({ tags: true, placeholder: "Output Standard",tokenSeparators: [',', ' '] });

$(".otprocessConnection").select2({ tags: true, placeholder: "Output Connection Type",tokenSeparators: [',', ' '] });


</script>

<script type="text/javascript" class="js-code-example-tokenizer"> 

//process scrip select

$(".processsuggestion").select2({ tags: true,placeholder: "Process Type", tokenSeparators: [',', ' '] });

$(".processsuggestionStand").select2({ tags: true,placeholder: "Process Standard", tokenSeparators: [',', ' '] });



</script>

	<script type="text/javascript">
		$(document).ready(function() {
		  $("#device_name").keyup(function() {
		    var x = document.getElementById('showSearchDiv');
		    if($(this).val() == "") {
		      // x.style.display = 'none';
		      $("#showSearchDiv").removeClass("show_div");
		    } else {
		      // x.style.display = 'block';

		      $("#showSearchDiv").addClass("show_div");
		    }
		  });
		});
	</script>
	<script type="text/javascript">
			$(".main_btn").click(function() {
			    $("#showSearchDiv").toggleClass("show_div");
			});
	</script>

	
	<script type="text/javascript">
		$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
	</script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.js" integrity="sha512-VvWznBcyBJK71YKEKDMpZ0pCVxjNuKwApp4zLF3ul+CiflQi6aIJR+aZCP/qWsoFBA28avL5T5HA+RE+zrGQYg==" crossorigin="anonymous"></script>

<script type="text/javascript">
  // bootstrap-tagsinput.js file - add in local
$(function() {
    $("input[data-role=tagsinput], select[multiple][data-role=tagsinput]").tagsinput();
  });
</script>

<script>
	function getprocess() {
	var process = $("#process").val();
$.ajax({
		url:"<?php echo base_url(); ?>/Product/getprocess",
		type:"POST",
		data: {process:process},
		success:function(data)
		{
				$('#processSugguestion').html(data);
				$("#processSugguestion").css("display", "block");
				return false;
		}
		
	});
}
$(document).on('click','#processSugguestion li',function(){
	var processName = $(this).html();
	var ID = $(this).attr('data-value');
	$("#productid").val(ID);
	$("#process").val(processName); 
	$("#processSugguestion").css("display", "none");
});
</script>

<script>
    (function () {
    "use strict";
    var hiddenItems = document.getElementsByClassName('hidden'), hidden;
    document.addEventListener('click', function (e) {
        for (var i = 0; hidden = hiddenItems[i]; i++) {
            if (!hidden.contains(e.target) && hidden.style.display != 'none')
                hidden.style.display = 'none';
        }
        if (e.target.getAttribute('data-toggle')) {
            var toggle = document.querySelector(e.target.getAttribute('data-toggle'));
            toggle.style.display = toggle.style.display == 'none' ? 'block' : 'none';
        }
    }, false);
})();
</script>

<?php 

$process_1 = $this->db->query('SELECT device_model FROM `product`  GROUP BY device_model')->result_array();
   $array=array();

   foreach($process_1 as $process_sugg){ 
$array[]=$process_sugg['device_model'];

    }

$deviceModelJson=json_encode($array);
?>

<script>
function autocomplete(inp, arr) {
  /*the autocomplete function takes two arguments,
  the text field element and an array of possible autocompleted values:*/
  var currentFocus;
  /*execute a function when someone writes in the text field:*/
  inp.addEventListener("input", function(e) {
      var a, b, i, val = this.value;
      /*close any already open lists of autocompleted values*/
      closeAllLists();
      if (!val) { return false;}
      currentFocus = -1;
      /*create a DIV element that will contain the items (values):*/
      a = document.createElement("DIV");
      a.setAttribute("id", this.id + "autocomplete-list");
      a.setAttribute("class", "autocomplete-items");
      /*append the DIV element as a child of the autocomplete container:*/
      this.parentNode.appendChild(a);
      /*for each item in the array...*/
      for (i = 0; i < arr.length; i++) {
        /*check if the item starts with the same letters as the text field value:*/
        if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
          /*create a DIV element for each matching element:*/
          b = document.createElement("DIV");
          /*make the matching letters bold:*/
          b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
          b.innerHTML += arr[i].substr(val.length);
          /*insert a input field that will hold the current array item's value:*/
          b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
          /*execute a function when someone clicks on the item value (DIV element):*/
          b.addEventListener("click", function(e) {
              /*insert the value for the autocomplete text field:*/
              inp.value = this.getElementsByTagName("input")[0].value;
              /*close the list of autocompleted values,
              (or any other open lists of autocompleted values:*/
              closeAllLists();
          });
          a.appendChild(b);
        }
      }
  });
  /*execute a function presses a key on the keyboard:*/
  inp.addEventListener("keydown", function(e) {
      var x = document.getElementById(this.id + "autocomplete-list");
      if (x) x = x.getElementsByTagName("div");
      if (e.keyCode == 40) {
        /*If the arrow DOWN key is pressed,
        increase the currentFocus variable:*/
        currentFocus++;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 38) { //up
        /*If the arrow UP key is pressed,
        decrease the currentFocus variable:*/
        currentFocus--;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 13) {
        /*If the ENTER key is pressed, prevent the form from being submitted,*/
        e.preventDefault();
        if (currentFocus > -1) {
          /*and simulate a click on the "active" item:*/
          if (x) x[currentFocus].click();
        }
      }
  });
  function addActive(x) {
    /*a function to classify an item as "active":*/
    if (!x) return false;
    /*start by removing the "active" class on all items:*/
    removeActive(x);
    if (currentFocus >= x.length) currentFocus = 0;
    if (currentFocus < 0) currentFocus = (x.length - 1);
    /*add class "autocomplete-active":*/
    x[currentFocus].classList.add("autocomplete-active");
  }
  function removeActive(x) {
    /*a function to remove the "active" class from all autocomplete items:*/
    for (var i = 0; i < x.length; i++) {
      x[i].classList.remove("autocomplete-active");
    }
  }
  function closeAllLists(elmnt) {
    /*close all autocomplete lists in the document,
    except the one passed as an argument:*/
    var x = document.getElementsByClassName("autocomplete-items");
    for (var i = 0; i < x.length; i++) {
      if (elmnt != x[i] && elmnt != inp) {
        x[i].parentNode.removeChild(x[i]);
      }
    }
  }
  /*execute a function when someone clicks in the document:*/
  document.addEventListener("click", function (e) {
      closeAllLists(e.target);
  });
}

/*An array containing all the country names in the world:*/
var countries = <?php echo $deviceModelJson;?>;

/*initiate the autocomplete function on the "myInput" element, and pass along the countries array as possible autocomplete values:*/
autocomplete(document.getElementById("device_name"), countries);
</script>