<?php include_once 'include/header.php' ; ?>


<section class="home_banner_area">
	<div class="banner_inner d-flex align-items-center">
		<div class="container-fluid">
			<div class="search-form-container">
				<form action="" class="search-form">
					<h1 id="search-form-title">search for devices, components, services</h1>


					<div class="search-container">
						<div class="search-inner-container" style="z-index: 1;">
                   

							 <ul class="nav nav-tabs search-container" role="tablist">
								<li class="nav-item search-channel-containe">
									<a class="nav-link rui-search-tab active" data-toggle="tab" href="#home">Devices</a>
								</li>
								<li class="nav-item search-channel-containe">
									<a class="nav-link rui-search-tab" data-toggle="tab" href="#menu1">Components</a>
								</li>
								<li class="nav-item search-channel-containe">
									<a class="nav-link rui-search-tab" data-toggle="tab" href="#menu2">Services</a>
								</li>
							</ul>	

							<div class="tab-content">

								<div id="home" class="container tab-pane active">
									<div class="search-inner-container" style="z-index: 1;">


										<div class="rui-search-container search-input-container">
											<i class="lnr lnr-magnifier"></i>

											<input class="rui-input rui-location-box rui-auto-complete-input" placeholder="Search for devices">

											<div class="clear-text-container">
												<a class="rui-icon rui-icon-cross" title="Clear text"> 
												</a>
											</div>
											<button class="rui-search-button">
												<span class="rui-visually">Search</span>
											</button>
											<div class="focus-border" style="display: none;"></div>
										</div>
<!-- <div class="search_more">

	<ul class="ul_search_more">
		<li class="ul_search_more_li">
			<aside class="left_widgets cat_widgets side_bar_nw">
						<div class="widgets_inner">
							<ul class="list">
						<li>
							<a href="#">Manufacturer <span class="lnr lnr-chevron-down"></span></a>
                           <ul class="list">
								<li class="d-flex justify-content-between align-items-center">
									<div class="primary-checkbox">
										<input type="checkbox" id="default-checkbox1" checked>
										<label for="default-checkbox1"></label>
									</div>
									<a href="#">Power Management ICs - PMIC</a>
								</li>
								<li class="d-flex justify-content-between align-items-center">
									<div class="primary-checkbox">
										<input type="checkbox" id="default-checkbox10">
										<label for="default-checkbox10"></label>
									</div>
									<a href="#">Amplifiers & Comparators </a></li>
								<li class="d-flex justify-content-between align-items-center">
									<div class="primary-checkbox">
										<input type="checkbox" id="default-checkbox11" checked> 
										<label for="default-checkbox11"></label>
									</div><a href="#">Microcontrollers - MCU</a></li>
								<li class="d-flex justify-content-between align-items-center">
									<div class="primary-checkbox">
										<input type="checkbox" id="default-checkbox12">
										<label for="default-checkbox12"></label>
									</div><a href="#">Logic</a></li>
								<li class="d-flex justify-content-between align-items-center">
									<div class="primary-checkbox">
										<input type="checkbox" id="default-checkbox13">
										<label for="default-checkbox13"></label>
									</div><a href="#">Drivers & Interfaces</a></li>
							</ul>
						</li>
					</ul>
				</div>
			</aside>
		</li>


						<li class="ul_search_more_li">
			            <aside class="left_widgets cat_widgets side_bar_nw">
						<div class="widgets_inner">
							<ul class="list">
						<li>
							<a href="#">Availability <span class="lnr lnr-chevron-down"></span></a>
                           <ul class="list">
								<li class="d-flex justify-content-between align-items-center">
									<div class="primary-checkbox">
										<input type="checkbox" id="default-checkbox21" checked>
										<label for="default-checkbox21"></label>
									</div>
									<a href="#">All</a>
								</li>
								<li class="d-flex justify-content-between align-items-center">
									<div class="primary-checkbox">
										<input type="checkbox" id="default-checkbox22">
										<label for="default-checkbox22"></label>
									</div>
									<a href="#">Next Day Delivery</a></li>
								<li class="d-flex justify-content-between align-items-center">
									<div class="primary-checkbox">
										<input type="checkbox" id="default-checkbox23" checked> 
										<label for="default-checkbox23"></label>
									</div><a href="#">1 - 7 Days</a></li>
								
							</ul>
						</li>

					</ul>
						</div>
					</aside>
		</li>
	</ul>
						
				</div> -->



									</div>
								</div>


								<div id="menu1" class="container tab-pane fade">
									<div class="search-inner-container" style="z-index: 1;">


										<div class="rui-search-container search-input-container">
											<i class="lnr lnr-magnifier"></i>

											<input class="rui-input rui-location-box rui-auto-complete-input" placeholder="Search for Components">

											<div class="clear-text-container">
												<a class="rui-icon rui-icon-cross" title="Clear text"> 
												</a>
											</div>
											<button class="rui-search-button">
												<span class="rui-visually">Search</span>
											</button>
											<div class="focus-border" style="display: none;"></div>
										</div>
									</div>
								</div>

								<div id="menu2" class="container tab-pane fade">
									<div class="search-inner-container" style="z-index: 1;">


										<div class="rui-search-container search-input-container">
											<i class="lnr lnr-magnifier"></i>

											<input class="rui-input rui-location-box rui-auto-complete-input" placeholder="Search for Services">

											<div class="clear-text-container">
												<a class="rui-icon rui-icon-cross" title="Clear text"> 
												</a>
											</div>
											<button class="rui-search-button">
												<span class="rui-visually">Search</span>
											</button>
											<div class="focus-border" style="display: none;"></div>
										</div>
									</div>
								</div>
							</div> 



						</div>
					</div>


					<div class="rui-clearfix"></div>

				</div>
			</form>
		</div>

	</div>
</div>


</section>





						<section class="feature_product_area">
							<div class="main_box" style="padding-top: 40px;">
								<div class="container-fluid">
                                    <div class="feature_product_inner">
										<div class="main_title">
											<h2>Latest Products</h2>
											<!-- <p>Who are in extremely love with eco friendly system.</p> -->
										</div>
										<div class="feature_p_slider owl-carousel">
											<div class="item">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro1.jpg" alt="">
													</div>
													<a href="#"><h4>Lorem Ipsum</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
											<div class="item">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro2.png" alt="">
													
													</div>
													<a href="#"><h4>Lorem Ipsum</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
											<div class="item">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro3.jpg" alt="">
														
													</div>
													<a href="#"><h4>Lorem Ipsum</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
											<div class="item">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro4.png" alt="">
														
													</div>
													<a href="#"><h4>Lorem Ipsum</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
											<div class="item">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro1.jpg" alt="">
													
													</div>
													<a href="#"><h4>Lorem Ipsum</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
											<div class="item">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro2.png" alt="">
													
													</div>
													<a href="#"><h4>Lorem Ipsum</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
											<div class="item">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro3.jpg" alt="">
													
													</div>
													<a href="#"><h4>Lorem Ipsum</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
											<div class="item">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro4.png" alt="">
													</div>
													<a href="#"><h4>Lorem Ipsum</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</section>


							<!-- <section class="clients_logo_area latest_product" >
							<div class="container">
								<div class="main_title">
											<h2>Latest Products</h2>
											<p>Lorem Ipsum is simply dummy text of the printing</p>
										</div>
							</div>
						</section> -->

						<section class="feature_product_area latest_product_area">
							<div class="main_box">
								<div class="container-fluid">
									<div class="feature_product_inner">
										<div class="main_title">
											<h2>New Products</h2>
										<!-- 	<p>Who are in extremely love with eco friendly system.</p> -->
										</div>
										<div class="latest_product_inner row mb-30" style="margin-bottom: 0 !important;">


											<div class="col-md">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro1.jpg" alt="">

													</div>
													<a href="#"><h4>Drivers & Interfaces</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>

											<div class="col-md">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro2.png" alt="">

													</div>
													<a href="#"><h4>Drivers & Interfaces</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>

											<div class="col-md">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro3.jpg" alt="">

													</div>
													<a href="#"><h4>Drivers & Interfaces</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>

											<div class="col-md">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro4.png" alt="">

													</div>
													<a href="#"><h4>Drivers & Interfaces</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
											<div class="col-md">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro4.png" alt="">

													</div>
													<a href="#"><h4>Drivers & Interfaces</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
										</div>

										<div class="latest_product_inner row" >
											<div class="col-md">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro2.png" alt="">

													</div>
													<a href="#"><h4>Drivers & Interfaces</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
											<div class="col-md">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro3.jpg" alt="">

													</div>
													<a href="#"><h4>Drivers & Interfaces</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
											<div class="col-md">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro4.png" alt="">

													</div>
													<a href="#"><h4>Drivers & Interfaces</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
											<div class="col-md">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro2.png" alt="">

													</div>
													<a href="#"><h4>Drivers & Interfaces</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
											<div class="col-md">
												<div class="f_p_item">
													<div class="f_p_img">
														<img class="img-fluid" src="img/pro3.jpg" alt="">

													</div>
													<a href="#"><h4>Drivers & Interfaces</h4></a>
													<h5>$150.00</h5>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</section>


						
                  <!-- <section class="feature_product_area">
							<div class="main_box">
								<div class="container-fluid">
									<div class="row">
										<div class="col-md-3 animated fadeIn">
											<div class="left_sidebar_area">
												<aside class="left_widgets cat_widgets">
													<div class="l_w_title">
														<h3>Search History</h3>
													</div>
													<div class="widgets_inner widgets_inner2">
														<ul class="list">
												<li>
													<a href="#">Connectors & Cable <span class="lnr lnr-chevron-right"></span></a>
                                                   <ul class="list" style="display: block;">
														<li><a href="#">Power Management ICs - PMIC</a></li>
														<li><a href="#">Amplifiers & Comparators </a></li>
														<li><a href="#">Microcontrollers - MCU</a></li>
														<li><a href="#">Logic</a></li>
														<li><a href="#">Drivers & Interfaces</a></li>
													</ul>
												</li>
												<li>
													<a href="#">Semiconductors <span class="lnr lnr-chevron-right"></span></a>
													<ul class="list">
														<li><a href="#">Power Management ICs - PMIC</a></li>
														<li><a href="#">Amplifiers & Comparators </a></li>
														<li><a href="#">Microcontrollers - MCU</a></li>
														<li><a href="#">Logic</a></li>
														<li><a href="#">Drivers & Interfaces</a></li>
													</ul>
												</li>
												<li><a href="#">Electromechanical <span class="lnr lnr-chevron-right"></span></a>
													<ul class="list">
														<li><a href="#">Power Management ICs - PMIC</a></li>
														<li><a href="#">Amplifiers & Comparators </a></li>
														<li><a href="#">Microcontrollers - MCU</a></li>
														<li><a href="#">Logic</a></li>
														<li><a href="#">Drivers & Interfaces</a></li>
													</ul>
												</li>
															<li><a href="#">Switches & Relays <span class="lnr lnr-chevron-right"></span></a>
																<ul class="list">
																	<li><a href="#">Switches</a></li>
																	<li><a href="#">Relays </a></li>
																	<li><a href="#">View All</a></li>
																</ul>
															</li>
									<li><a href="#">Power Supplies and Circuit Protection <span class="lnr lnr-chevron-right"></span></a>
										<ul class="list">
														<li><a href="#">Power Management ICs - PMIC</a></li>
														<li><a href="#">Amplifiers & Comparators </a></li>
														<li><a href="#">Microcontrollers - MCU</a></li>
														<li><a href="#">Logic</a></li>
														<li><a href="#">Drivers & Interfaces</a></li>
													</ul>

									</li>
									<li><a href="#">Test & Measurement <span class="lnr lnr-chevron-right"></span></a>
										<ul class="list">
														<li><a href="#">Power Management ICs - PMIC</a></li>
														<li><a href="#">Amplifiers & Comparators </a></li>
														<li><a href="#">Microcontrollers - MCU</a></li>
														<li><a href="#">Logic</a></li>
														<li><a href="#">Drivers & Interfaces</a></li>
													</ul>
									</li>
									<li><a href="#">View New Products <span class="lnr lnr-chevron-right"></span></a>
										<ul class="list">
														<li><a href="#">Power Management ICs - PMIC</a></li>
														<li><a href="#">Amplifiers & Comparators </a></li>
														<li><a href="#">Microcontrollers - MCU</a></li>
														<li><a href="#">Logic</a></li>
														<li><a href="#">Drivers & Interfaces</a></li>
													</ul>
									</li>
														</ul>
													</div>
												</aside>
												
											</div>
										</div>
										<div class="col-md-6 animated fadeIn">
											<div class="row most_product_inner">
										<div class="col-lg-6 col-sm-6">
											<div class="most_p_list list_nw">
												<h3>Popular Products</h3>
												<div class="media">
													<div class="d-flex">
														<img class="img-fluid" src="img/pro1.jpg" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Computer accessories</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												<div class="media">
													<div class="d-flex">
													<img class="img-fluid" src="img/pro2.png" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Motherboard - HDDI</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												<div class="media">
													<div class="d-flex">
													<img class="img-fluid" src="img/pro3.jpg" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Computer accessories</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>

												<div class="media">
													<div class="d-flex">
													<img class="img-fluid" src="img/pro2.png" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>HDDI - Motherboard</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>


												<p class="text-center info info_2">
													<a href="#">View All</a>
												</p>

											</div>
										</div>
										<div class="col-lg-6 col-sm-6">
											<div class="most_p_list list_nw">
												<h3>New Products</h3>
												<div class="media">
													<div class="d-flex">
														<img class="img-fluid" src="img/pro4.png" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>HDDI - Motherboard</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												<div class="media">
													<div class="d-flex">
													<img class="img-fluid" src="img/pro1.jpg" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Computer accessories</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												<div class="media">
													<div class="d-flex">
														<img class="img-fluid" src="img/pro2.png" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Motherboard</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												<div class="media">
													<div class="d-flex">
														<img class="img-fluid" src="img/pro4.png" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Accessories</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												<p class="text-center info info_2">
													<a href="#">View All</a>
												</p>
											</div>
										</div>
									</div>
										</div>
										<div class="col-md-3">
											<div class="google_ad">
												<img src="img/google_ad.png">
											</div>
										</div>
									</div>
									
								</div>
							</div>
						</section> -->


						<section class="most_product_area animated fadeIn">
							<div class="main_box">
								<div class="container-fluid">
									<div class="main_title">
										<h2 class="no-marg">Most Searched Products</h2>
										<p>Who are in extremely love with eco friendly system.</p>
									</div>
									<div class="row most_product_inner">
										<div class="col-lg-3 col-sm-6">
											<div class="most_p_list">
												<div class="media">
													<div class="d-flex">
														<img class="img-fluid" src="img/pro1.jpg" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>HDDI - Motherboard</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												<div class="media">
													<div class="d-flex">
													<img class="img-fluid" src="img/pro3.jpg" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Computer accessories</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												<div class="media">
													<div class="d-flex">
														<img class="img-fluid" src="img/pro2.png" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Motherboard</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												
											</div>
										</div>
										<div class="col-lg-3 col-sm-6">
											<div class="most_p_list">
												<div class="media">
													<div class="d-flex">
														<img class="img-fluid" src="img/pro4.png" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Motherboard</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												<div class="media">
													<div class="d-flex">
														<img class="img-fluid" src="img/pro2.png" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>HDDI - Motherboard</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												<div class="media">
													<div class="d-flex">
														<img class="img-fluid" src="img/pro1.jpg" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Computer accessories</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
											</div>
										</div>
										<div class="col-lg-3 col-sm-6">
											<div class="most_p_list">
												<div class="media">
													<div class="d-flex">
														<img class="img-fluid" src="img/pro1.jpg" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Computer accessories</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												<div class="media">
													<div class="d-flex">
														<img class="img-fluid" src="img/pro2.png" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Motherboard</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												<div class="media">
													<div class="d-flex">
													<img class="img-fluid" src="img/pro3.jpg" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Motherboard - HDDI</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
											</div>
										</div>
										<div class="col-lg-3 col-sm-6">
											<div class="most_p_list">
												<div class="media">
													<div class="d-flex">
														<img class="img-fluid" src="img/pro4.png" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Computer</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												<div class="media">
													<div class="d-flex">
														<img class="img-fluid" src="img/pro1.jpg" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Motherboard - HDDI</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
												<div class="media">
													<div class="d-flex">
														<img class="img-fluid" src="img/pro2.png" alt="">
													</div>
													<div class="media-body">
														<a href="#"><h4>Accessories</h4></a>
														<h3>$189.00</h3>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</section>


						<section class="clients_logo_area animated fadeIn">
							<div class="container-fluid">
								<div class="main_title">
									<h2 class="no-marg">Top Brands</h2>
									<p >Who are in extremely love with eco friendly system.</p>
								</div>
								<div class="clients_slider owl-carousel">
									<div class="item">
										<img src="img/clients-logo/c-logo-1.png" alt="">
									</div>
									<div class="item">
										<img src="img/clients-logo/c-logo-2.png" alt="">
									</div>
									<div class="item">
										<img src="img/clients-logo/c-logo-3.png" alt="">
									</div>
								</div>
							</div>
						</section>



<?php include_once 'include/footer.php' ; ?>
					