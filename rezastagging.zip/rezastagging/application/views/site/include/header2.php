<!doctype html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- <link rel="icon" href="<?php echo base_url();?>assets/site/img/favicon.png" type="image/png"> -->
	<title>Reza</title>

	<link rel="stylesheet" href="<?php echo base_url();?>assets/site/css/bootstrap.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/site/vendors/linericon/style.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/site/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/site/vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/site/vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/site/vendors/nice-select/<?php echo base_url();?>assets/site/css/nice-select.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/site/vendors/animate-<?php echo base_url();?>assets/site/css/animate.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/site/vendors/jquery-ui/jquery-ui.css">

	<link rel="stylesheet" href="<?php echo base_url();?>assets/site/css/style2.css?time=<?php echo time(); ?>">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/site/css/responsive.css?time=<?php echo time(); ?>">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/site/css/custom.css?time=<?php echo time(); ?>">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css" />


	<style type="text/css">
		.nav-item.main_menu_item {
	font-size: 15px;
	font-weight: 500;
	margin: 10px 0 0 15px !important;
}
.img_top {
	width: 35px;
	height: 35px;
	border: 1px solid #000;
	border-radius: 50%;
	margin-right: 5px;
}
	</style>
</head>
<body>

	<header class="header_area">
	
		<div class="main_menu">
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container">

					<a class="navbar-brand logo_h" href="<?php echo base_url();?>"><img src="<?php echo base_url();?>assets/site/img/logo.png" alt=""></a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>

					<div class="collapse navbar-collapse offset" id="navbarSupportedContent">
						<ul class="nav navbar-nav menu_nav ml-auto">
							<li class="nav-item active"><a class="nav-link" href="<?php echo base_url();?>">Home</a></li>
<!-- 							<li class="nav-item"><a class="nav-link" onclick="return alert('comming soon');" href="#">About</a></li>
 -->							<li class="nav-item"><a class="nav-link" onclick="return alert('comming soon');" href="#">Services</a></li>
							<li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>search-listing">Devices</a></li>
							<li class="nav-item <?php if($page=='contact-us'){echo 'active';}?>"><a class="nav-link" href="<?php echo base_url();?>contact-us">Contact Us</a></li>
							
							<!-- <li class="nav-item submenu dropdown">
							<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Services</a>
							 <ul class="dropdown-menu">
							
							<li class="nav-item"><a class="nav-link" href="#">List Products</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Products</a></li>

							</ul> 
						</li> -->

						

						<!--<li class="nav-item submenu dropdown">
							<a href="conactus.php" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Contact Us</a>
							 <ul class="dropdown-menu">
								
								<li class="nav-item"><a class="nav-link" href="#">Product Category 1</a></li>
								<li class="nav-item"><a class="nav-link" href="#">Product Category 2</a></li>

							</ul> 
						</li>-->
						<?php if(!$this->session->userdata('user_id')) { ?>
						
							<li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>login">Login</a></li>
							<li class="nav-item "><a class="btn main_btn signup_btn spance_nav" href="<?php echo base_url();?>signup">Sign Up</a></li>
						
<?php } else{
  $user = $this->common_model->GetSingleData('users',array('user_id' =>$this->session->userdata('user_id')));

?>

	<li class="nav-item submenu dropdown user_login">
							<a href="conactus.php" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
	<img class="img_top" <?php if(!empty($user['profile'])){ ?>  src="<?php echo base_url();?>assets/profile/<?php echo $user['profile'];?>" <?php } else { ?> src="<?php echo base_url();?>assets/profile/user.png"   <?php } ?> >
								<!-- <i class="lnr lnr-user"></i> -->
						<?php echo $user['fname'];?></a>
							 <ul class="dropdown-menu">
								<li class="nav-item main_menu_item bolde_onl">Profile</li>
							 	
								<li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>profile">My Profile</a></li>

								<li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>change-password">Change Password</a></li>

								<li class="nav-item"><a class="nav-link"  href="<?php echo base_url();?>profile">Change Photo</a></li>

								<li class="nav-item main_menu_item border_font">Items management</li>

								<li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>add-product">Add Item</a></li>

								<!--<li class="nav-item"><a class="nav-link" onclick="return alert('comming soon');" href="#">Delete an Item</a></li>-->

								<li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>my-product-listing">My List</a></li>

								<li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>my-fav-listing">Favorite Listing</a></li>

								<li class="nav-item main_menu_item border_font">Financials </li>

								<li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>transaction">Transaction History</a></li>
								<li class="nav-item"><a class="nav-link" onclick="return alert('comming soon');" href="#">Payment details</a></li>
								<li class="nav-item"><a class="nav-link" onclick="return alert('comming soon');" href="#">Credit cards</a></li>
								
							   <li class="nav-item main_menu_item border_font">Support Management</li>
							   
							   <!--<li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>ticket">Help Desk</a></li>-->

								<!--<li class="nav-item main_menu_item border_font">Help and Support</li>-->

								<!--<li class="nav-item"><a onclick="return alert('comming soon');" class="nav-link" href="#">Contact Us</a></li>-->



							<li class="nav-item"><a onclick="return (confirm('Are you sure?'))" class="nav-link" href="<?php echo base_url();?>logout">Logout</a></li>
							</ul> 
						</li>
								

<?php } ?>
						</ul>


					<!-- 	<ul class="nav navbar-nav navbar-right">
							<li class="nav-item"><a href="#" class="cart"><i class="lnr lnr lnr-cart"></i></a></li>
							<li class="nav-item"><a href="#" class="search"><i class="lnr lnr-magnifier"></i></a></li>
						</ul> -->

					<!-- <?php if(!$this->session->userdata('user_id')) { ?>
						<ul class="nav navbar-nav navbar-right">
							<li><a class="btn main_btn Login_btn" href="<?php echo base_url();?>login">Login</a></li>
							<li><a class="btn main_btn signup_btn" href="<?php echo base_url();?>signup">Sign Up</a></li>
						</ul>
<?php } else{ ?>
							<ul class="nav navbar-nav navbar-right">

							<li><a class="btn main_btn signup_btn" href="<?php echo base_url();?>profile">Profile</a></li>
							<li><a class="btn main_btn signup_btn" href="<?php echo base_url();?>logout">Logout</a></li>
</ul>

<?php } ?> -->


										</div>
									</div>
								</nav>
							</div>
						</header>
					