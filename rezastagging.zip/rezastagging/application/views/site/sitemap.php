<?php include_once 'include/header.php'; ?>
<style type="text/css">
  /*.about-area .text-heading.title_color {
  font-size: 35px;
  text-align: center;
  color: #0a66c2;
}*/
/*.about-area .sample-text {
  font-size: 18px;
  line-height: 35px !important;
  color: #333;
  text-align: center;
  width: 70%;
  margin: 0 auto;
}
*/
.home_banner_area.home_banner_area_about {
  background: #fff;
}
.img_right_side img {
  width: 100%;
  box-shadow: 0 10px 29px rgba(0, 0, 0, 0.09);
  height: 300px;
  object-fit: cover;
  border-radius: 30px;
}
.sample-text-area p {
  line-height: 26px;
  width: 80%;
  font-size: 18px;
}
.sample-text-area.about-area {
  background: #e8f0f2;
}
.clients_logo_area .clients_logo_area_about_area  {
  background: #fff;
  padding: 70px 0;
}
.right_img img {
  width: 100%;
}
.sample-text-area.about-area.about_values {
  background: #fff;
}
.sample-text-area.about-area.about_values p {
  line-height: 20px;
  width: 80%;
  font-size: 15px;
  color: #333;
} 
.sample-text-area.about-area.about_values h4 {
  font-size: 18px;
  color: #000;
}
.clients_logo_area.clients_logo_area_about_area.animated.fadeIn {
  /*background-image: url('img/banner222.jpg') !important;*/
  background: #e5ecee !important;
  background: #fff;
  padding-top: 50px;
  padding-bottom: 50px;
}
.sample-text-area.about-area .title_color {
  color: #0a66c2;
}
</style>
<section class="home_banner_area home_banner_area_about">
  <div class="banner_inner d-flex align-items-center" style="padding-bottom: 30px;">
    <div class="container">
      <div class="banner_content row">
       
        <div class="col-lg-12">
          <h3>Sitemap</h3>
          <p style="text-align: justify;">
John Wiley & Sons, Inc. and its subsidiary and affiliate companies (collectively, “Wiley,” “we,” “us” or “our”) recognize the importance of protecting the personal information collected from users in the operation of its services and taking reasonable steps to maintain the security, integrity and privacy of any information in accordance with this Privacy Policy. By submitting your information to Wiley you consent to the practices described in this policy. If you are less than 18 years of age, then you must first seek the consent of your parent or guardian prior to submitting any personal information.

This Privacy Policy describes how Wiley collects and uses the personal information you provide to Wiley. It also describes the choices available to you regarding our use of your personal information and how you can access and update this information.

       

          </p>
        </div>
        
      </div>
    </div>
  </div>
</section>















<?php include_once 'include/footer.php'; ?>