<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['google_client_id']="918084231293-o3n4vnods0jkhuldi3bqgjikc8o9qo15.apps.googleusercontent.com";
$config['google_client_secret']="-PryTvioi48aaLOd_mJdzcXg";
$config['google_redirect_url']='https://www.webwiders.com/WEB01/Buyer-Seller/google_login';

